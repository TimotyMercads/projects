﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_OOP
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            SigninForm signinForm = new SigninForm();
            signinForm.Show();
            this.Close();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Admin Succesfully Loaded");
            lblRole.Text = "Role: Admin";
        }
    }
}
