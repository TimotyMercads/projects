﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_OOP
{
    public partial class UserForm : Form
    {

        private readonly Dictionary<string, List<ServiceItem>> services;
        public UserForm()
        {
            InitializeComponent();
            services = new Dictionary<string, List<ServiceItem>>();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            SigninForm signinForm = new SigninForm();
            signinForm.Show();
            this.Close();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {
            MessageBox.Show("User Succesfully Loaded");
            lblRole.Text = "Role: User";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtBookingCost_TextChanged(object sender, EventArgs e)
        {
            txtBookingCost.ReadOnly = true;
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            var selectedItem = GetSelectedServiceItem();
            if (selectedItem == null)
            {
                MessageBox.Show("Please select an item to book.");
                return;
            }

            var bookingDate = dtpBookingDate.Value.Date;
            if (selectedItem.UnavailableDates.Contains(bookingDate))
            {
                MessageBox.Show("The selected item is unavailable on this date.");
                return;
            }


            selectedItem.UnavailableDates.Add(bookingDate);


            var hours = (bookingDate - DateTime.Now).TotalHours;
            if (hours < 0)
            {
                MessageBox.Show("Please select a future date and time.");
                return;
            }

            var totalCost = selectedItem.Rate * (decimal)hours;
            txtBookingCost.Text = $"Total cost: ${totalCost:F2}";


            SaveBookingDataToFile();


            btnLoadData_Click(sender, e);

            MessageBox.Show("Booking successfully saved.");
        }

        private void SaveBookingDataToFile()
        {
            string filePath = @"C:/Users/trystal shane manuel/OneDrive/Desktop/Timoty/OOP Final Proj/services.txt";

            try
            {
                using (var writer = new StreamWriter(filePath, false))
                {
                    foreach (var category in services.Keys)
                    {
                        writer.WriteLine(category);

                        foreach (var item in services[category])
                        {
                            var unavailableDates = string.Join(",", item.UnavailableDates.Select(d => d.ToString("yyyy-MM-dd")));
                            writer.WriteLine($"{item.Name}|{item.Rate}|{unavailableDates}");
                        }
                    }
                }

                MessageBox.Show("Booking data updated successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message);
            }
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            string filePath = @"C:/Users/trystal shane manuel/OneDrive/Desktop/Timoty/OOP Final Proj/services.txt";

            try
            {
                cboServiceCategory.Items.Clear();
                services.Clear(); 

                using (var reader = new StreamReader(filePath))
                {
                    string category = string.Empty;
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        if (line.Contains("|"))
                        {
                            var parts = line.Split('|');
                            var itemName = parts[0];
                            var rate = decimal.Parse(parts[1]);
                            var unavailableDates = parts[2].Split(',')
                                .Select(d => DateTime.Parse(d))
                                .ToList();

                            var serviceItem = new ServiceItem(itemName, rate, unavailableDates);

                            services[category].Add(serviceItem);
                        }
                        else
                        {
                          
                            category = line;
                            services[category] = new List<ServiceItem>();
                            cboServiceCategory.Items.Add(category);
                        }
                    }
                }

                MessageBox.Show("Data loaded successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }

        }

        private void cboServiceCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstItems.Items.Clear();
            lstUnavailableDates.Items.Clear();
            lblRate.Text = string.Empty;
            txtBookingCost.Clear();

            var selectedCategory = cboServiceCategory.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedCategory) || !services.ContainsKey(selectedCategory)) return;

            foreach (var item in services[selectedCategory])
                lstItems.Items.Add(item.Name);
        }

        private void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedItem = GetSelectedServiceItem();
            if (selectedItem == null) return;

            lblRate.Text = $"Rate: ₱{selectedItem.Rate} per day";
            lstUnavailableDates.Items.Clear();
            foreach (var date in selectedItem.UnavailableDates)
                lstUnavailableDates.Items.Add(date.ToShortDateString());
        }
        private ServiceItem GetSelectedServiceItem()
        {
            if (lstItems.SelectedItem == null) return null;
            var selectedName = lstItems.SelectedItem.ToString();
            var selectedCategory = cboServiceCategory.SelectedItem?.ToString();

            return services[selectedCategory].FirstOrDefault(item => item.Name == selectedName);
        }

        private void dtpBookingDate_ValueChanged(object sender, EventArgs e)
        {
            var selectedItem = GetSelectedServiceItem();
            if (selectedItem == null)
            {
                return;
            }

            var bookingDate = dtpBookingDate.Value.Date;


            if (selectedItem.UnavailableDates.Contains(bookingDate))
            {
                txtBookingCost.Text = "Selected date is unavailable.";
                return;
            }


            var hours = (bookingDate - DateTime.Now).TotalHours;
            if (hours < 0)
            {
                txtBookingCost.Text = "Please select a future date.";
                return;
            }

            var totalCost = selectedItem.Rate * (decimal)hours;
            txtBookingCost.Text = $"Total cost: ₱{totalCost:F2}";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var selectedItem = GetSelectedServiceItem();
            if (selectedItem == null)
            {
                MessageBox.Show("Please select an item to cancel.");
                return;
            }

            var bookingDate = dtpBookingDate.Value.Date;
            if (!selectedItem.UnavailableDates.Contains(bookingDate))
            {
                MessageBox.Show("No booking found for the selected date.");
                return;
            }

           
            selectedItem.UnavailableDates.Remove(bookingDate);

          
            if (selectedItem.UnavailableDates.Count == 0)
            {
                var selectedCategory = cboServiceCategory.SelectedItem?.ToString();
                services[selectedCategory].Remove(selectedItem);
                MessageBox.Show("The service item has been removed due to no bookings.");
            }
            else
            {
                MessageBox.Show("Booking successfully canceled.");
            }

            
            txtBookingCost.Clear();

         
            SaveBookingDataToFile();

       
            btnLoadData_Click(sender, e);
        }

        
    }


    public class ServiceItem
    {
        public ServiceItem(string name, decimal rate, List<DateTime> unavailableDates)
        {
            Name = name;
            Rate = rate;
            UnavailableDates = unavailableDates;
        }

        public string Name { get; }
        public decimal Rate { get; }
        public List<DateTime> UnavailableDates { get; }
    }
}
