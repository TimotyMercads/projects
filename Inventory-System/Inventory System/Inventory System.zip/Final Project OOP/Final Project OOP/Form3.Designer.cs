﻿namespace Final_Project_OOP
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLogout = new Button();
            lblRole = new Label();
            cboServiceCategory = new ComboBox();
            label1 = new Label();
            lblRate = new Label();
            lstItems = new ListBox();
            lstUnavailableDates = new ListBox();
            btnBook = new Button();
            dtpBookingDate = new DateTimePicker();
            label2 = new Label();
            txtBookingCost = new TextBox();
            label3 = new Label();
            btnLoadData = new Button();
            btnDelete = new Button();
            SuspendLayout();
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogout.Location = new Point(676, 12);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(112, 41);
            btnLogout.TabIndex = 5;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // lblRole
            // 
            lblRole.AutoSize = true;
            lblRole.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRole.Location = new Point(12, 9);
            lblRole.Name = "lblRole";
            lblRole.Size = new Size(65, 24);
            lblRole.TabIndex = 6;
            lblRole.Text = "label1";
            // 
            // cboServiceCategory
            // 
            cboServiceCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cboServiceCategory.FormattingEnabled = true;
            cboServiceCategory.Location = new Point(299, 65);
            cboServiceCategory.Name = "cboServiceCategory";
            cboServiceCategory.Size = new Size(369, 28);
            cboServiceCategory.TabIndex = 7;
            cboServiceCategory.SelectedIndexChanged += cboServiceCategory_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 69);
            label1.Name = "label1";
            label1.Size = new Size(281, 24);
            label1.TabIndex = 8;
            label1.Text = "What would you like to rent?";
            label1.Click += label1_Click;
            // 
            // lblRate
            // 
            lblRate.AutoSize = true;
            lblRate.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRate.Location = new Point(12, 137);
            lblRate.Name = "lblRate";
            lblRate.Size = new Size(60, 24);
            lblRate.TabIndex = 9;
            lblRate.Text = "Rate:";
            // 
            // lstItems
            // 
            lstItems.FormattingEnabled = true;
            lstItems.Location = new Point(27, 180);
            lstItems.Name = "lstItems";
            lstItems.Size = new Size(346, 204);
            lstItems.TabIndex = 10;
            lstItems.SelectedIndexChanged += lstItems_SelectedIndexChanged;
            // 
            // lstUnavailableDates
            // 
            lstUnavailableDates.FormattingEnabled = true;
            lstUnavailableDates.Location = new Point(422, 180);
            lstUnavailableDates.Name = "lstUnavailableDates";
            lstUnavailableDates.Size = new Size(346, 204);
            lstUnavailableDates.TabIndex = 11;
            // 
            // btnBook
            // 
            btnBook.Location = new Point(481, 402);
            btnBook.Name = "btnBook";
            btnBook.Size = new Size(159, 29);
            btnBook.TabIndex = 12;
            btnBook.Text = "Confirm Booking";
            btnBook.UseVisualStyleBackColor = true;
            btnBook.Click += btnBook_Click;
            // 
            // dtpBookingDate
            // 
            dtpBookingDate.Location = new Point(153, 102);
            dtpBookingDate.Name = "dtpBookingDate";
            dtpBookingDate.Size = new Size(261, 27);
            dtpBookingDate.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 104);
            label2.Name = "label2";
            label2.Size = new Size(135, 24);
            label2.TabIndex = 15;
            label2.Text = "Date to Rent:";
            // 
            // txtBookingCost
            // 
            txtBookingCost.Location = new Point(178, 403);
            txtBookingCost.Name = "txtBookingCost";
            txtBookingCost.Size = new Size(271, 27);
            txtBookingCost.TabIndex = 16;
            txtBookingCost.TextChanged += txtBookingCost_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(27, 403);
            label3.Name = "label3";
            label3.Size = new Size(145, 24);
            label3.TabIndex = 17;
            label3.Text = "Booking Cost:";
            // 
            // btnLoadData
            // 
            btnLoadData.Location = new Point(509, 100);
            btnLoadData.Name = "btnLoadData";
            btnLoadData.Size = new Size(159, 29);
            btnLoadData.TabIndex = 18;
            btnLoadData.Text = "Load Data";
            btnLoadData.UseVisualStyleBackColor = true;
            btnLoadData.Click += btnLoadData_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(509, 145);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(159, 29);
            btnDelete.TabIndex = 19;
            btnDelete.Text = "Cancel Booking";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // UserForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDelete);
            Controls.Add(btnLoadData);
            Controls.Add(label3);
            Controls.Add(txtBookingCost);
            Controls.Add(label2);
            Controls.Add(dtpBookingDate);
            Controls.Add(btnBook);
            Controls.Add(lstUnavailableDates);
            Controls.Add(lstItems);
            Controls.Add(lblRate);
            Controls.Add(label1);
            Controls.Add(cboServiceCategory);
            Controls.Add(lblRole);
            Controls.Add(btnLogout);
            Name = "UserForm";
            Text = "User";
            Load += UserForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnLogout;
        private Label lblRole;
        private ComboBox cboServiceCategory;
        private Label label1;
        private Label lblRate;
        private ListBox lstItems;
        private ListBox lstUnavailableDates;
        private Button btnBook;
        private DateTimePicker dtpBookingDate;
        private Label label2;
        private TextBox txtBookingCost;
        private Label label3;
        private Button btnLoadData;
        private Button btnDelete;
    }
}