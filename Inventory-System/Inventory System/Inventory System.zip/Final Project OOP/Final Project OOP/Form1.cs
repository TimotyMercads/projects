using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Final_Project_OOP
{
    public partial class SigninForm : Form
    {
        public SigninForm()
        {
            InitializeComponent();

            this.AcceptButton = btnLogin;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                var lines = File.ReadAllLines("C:/Users/trystal shane manuel/OneDrive/Desktop/Timoty/OOP Final Proj/users.txt");
                var user = lines.Select(line => line.Split(',')).FirstOrDefault(u => u[0] == username && u[1] == password);

                if (user != null)
                {
                    string role = user[2];

                    if (role == "Admin")
                    {
                        AdminForm adminForm = new AdminForm();
                        adminForm.Show();
                    }
                    else if (role == "User")
                    {
                        UserForm userForm = new UserForm();
                        userForm.Show();
                    }

                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex) {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            }
         }
    }
}







